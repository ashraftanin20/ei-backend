export class TokenAuthenticator {
}
